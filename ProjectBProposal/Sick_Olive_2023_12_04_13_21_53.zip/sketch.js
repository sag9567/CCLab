let currentImage;
let leaves = [];
let codeStarted = false;

class Leaf {
  constructor() {
    this.x = random(width);
    this.y = random(-50, -10);
    this.speed = random(1, 3);
    this.angle = random(PI);
    this.size = random(15, 25); // Increase the size of the leaves
  }

  update() {
    this.y += this.speed;
    this.x += 0.5 * sin(this.angle);
    this.angle += 0.05;

    if (this.y > height) {
      this.y = random(-50, -10);
      this.x = random(width);
    }
  }

  display() {
    fill(0, 100, 0); // Dark green color for all leaves
    noStroke();
    ellipse(this.x, this.y, this.size, this.size * 1.5);
  }

  touchesOlive() {
    // Check if the leaf touches a green color in the image
    let greenThreshold = 50; // Adjust this threshold as needed
    let pixelColor = currentImage.get(floor(this.x), floor(this.y));

    // Check if the pixel color is dark greenish
    return green(pixelColor) > greenThreshold && red(pixelColor) < greenThreshold && blue(pixelColor) < greenThreshold;
  }
}

function preload() {
  // Load the initial image
  currentImage = loadImage('images-2.png');
}

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);

  if (codeStarted) {
    // Display the current image
    image(currentImage, 0, 0, width, height);

    // Update and display each leaf
    for (let i = 0; i < leaves.length; i++) {
      leaves[i].update();
      leaves[i].display();

      // Check if a leaf touches the olive
      if (leaves[i].touchesOlive()) {
        // Change the image or perform any other action
        changeImage('images-5.png');
      }
    }
  }
}

function changeImage(newImagePath) {
  // Change the image
  currentImage = loadImage(newImagePath);
}

function mousePressed() {
  // Start the code when the mouse is clicked on the canvas
  codeStarted = true;

  // Create a certain number of leaves when the mouse is clicked
  for (let i = 0; i < 10; i++) {
    leaves.push(new Leaf());
  }
}
